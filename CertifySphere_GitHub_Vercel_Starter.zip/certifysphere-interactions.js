const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});

mainNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

const filterButtons = [...document.querySelectorAll(".filter-pill")];
const updateCards = [...document.querySelectorAll(".update-card")];
const searchInput = document.getElementById("updateSearch");
const emptyState = document.getElementById("emptyState");
let activeFilter = "all";

function filterUpdates() {
  const query = searchInput.value.trim().toLowerCase();
  let visibleCount = 0;
  updateCards.forEach((card) => {
    const matchesCategory = activeFilter === "all" || card.dataset.category === activeFilter;
    const matchesSearch = card.textContent.toLowerCase().includes(query);
    const visible = matchesCategory && matchesSearch;
    card.hidden = !visible;
    if (visible) visibleCount += 1;
  });
  emptyState.hidden = visibleCount !== 0;
}

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    filterButtons.forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    activeFilter = button.dataset.filter;
    filterUpdates();
  });
});
searchInput.addEventListener("input", filterUpdates);

document.getElementById("currentYear").textContent = new Date().getFullYear();

document.getElementById("newsletterForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const message = document.getElementById("formMessage");
  message.textContent = "Thanks! This demo is not connected to an email service, so your address was not sent or stored.";
  document.getElementById("emailAddress").value = "";
});
