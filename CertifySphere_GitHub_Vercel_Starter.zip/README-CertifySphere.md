# CertifySphere

A responsive static website for certification updates, certification discovery, exam preparation guidance, and learning resources.

## Project files

- `certifysphere-home.html` — website page
- `certifysphere-styles.css` — responsive styling
- `certifysphere-interactions.js` — navigation, update filters, search, and demo newsletter response
- `vercel.json` — Vercel routing configuration

## Run locally

1. Extract the ZIP file.
2. Open `certifysphere-home.html` in a browser.

Optional: use the VS Code Live Server extension and open the project folder.

## Publish with GitHub

1. Sign in to GitHub and create a new **public** repository, for example `certifysphere-learning-hub`.
2. Extract this ZIP on your computer.
3. In the new repository, choose **Add file → Upload files**.
4. Upload all four project files (not the ZIP itself).
5. Select **Commit changes**.

## Deploy with Vercel

1. Sign in to Vercel using GitHub.
2. Select **Add New → Project**.
3. Import `certifysphere-learning-hub`.
4. Framework Preset: **Other**.
5. Build Command: leave blank.
6. Output Directory: leave as `.` (project root).
7. Click **Deploy**.

The supplied `vercel.json` rewrites the root URL to the custom HTML homepage.

## Before submitting / checklist

- [ ] Extract the ZIP and confirm all project files are present.
- [ ] Open the website locally.
- [ ] Test navigation links and mobile menu.
- [ ] Test category filters and update search.
- [ ] Check external links and confirm they point to official provider/resource pages.
- [ ] Check the layout on desktop and mobile.
- [ ] Create a GitHub repository and upload the project files.
- [ ] Import the GitHub repository into Vercel and deploy.
- [ ] Open the live Vercel URL and test it.
- [ ] Replace sample content with verified, current announcements before presenting it as a live updates service.

## Important notes

- This is a front-end static demo. It does not include a database, admin dashboard, or content management system.
- The newsletter form is a demonstration only. It does not collect or send email addresses. Connect a trusted form or mailing-list provider before using it.
- Sample update cards are learning-resource highlights, not claims of newly announced exam changes. Verify exam dates, fees, eligibility, and objectives on the provider's official site.
- Google Fonts requires an internet connection; the site otherwise works as a static page.
